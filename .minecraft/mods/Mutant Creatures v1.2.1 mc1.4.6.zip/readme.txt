<<Mutant Creatures>>
by thehippomaster21

Version 1.2.1:
~fixed mutant snow golem drops glitching