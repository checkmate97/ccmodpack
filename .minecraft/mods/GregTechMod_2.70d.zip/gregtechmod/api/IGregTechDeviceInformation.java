package gregtechmod.api;

/**
 * You are allowed to include this File in your Download, as i will not change it.
 */
public interface IGregTechDeviceInformation {
	public String getMainInfo();
	public String getSecondaryInfo();
	public String getTertiaryInfo();
	public boolean isGivingInformation();
}
